#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <locale.h>
#include <time.h>
#include <sys/time.h>
#include <string.h>
#include <windows.h>

//Cores de fonte
#define BLKC "\e[0;30m"
#define REDC "\e[0;31m"
#define GRNC "\e[0;32m"
#define YELC "\e[0;33m"
#define CYNC "\e[0;36m"
#define WHTC "\e[0;37m"

//Cores de Background
#define BLKB "\e[40m"
#define REDB "\e[41m"
#define GRNB "\e[42m"
#define YELB "\e[43m"
#define CYNB "\e[46m"
#define WHTB "\e[47m"

#define WHTH "\e[0;107m"
#define WHTU "\e[4;37m"

//Reseta formata��o
#define RSET "\e[0;0m"

//Teclas de controle
#define ENTER 13
#define ESC 27
#define ARROW_UP 72
#define ARROW_LEFT  75
#define ARROW_RIGHT 77
#define ARROW_DOWN 80

//Espaco necessario para cada bloco
#define espaco "  "

//Defini a margem a esquerda
#define MARGIN_LEFT 15

//Espa�o entre a Tela e a Barra Lateral
#define ESPACO_LATERAL 4

#define LARGURA_MAX 27 //Vale ressaltar que a LARGURA_MAX representa apenas a metade da tela
#define ALTURA_MAX 25

//-----------//-------//------Structs

//Struct do jogador: Coordenada, pontos e combo
typedef struct{
    char nome[17];
    float pontuacao;
    int combo;
    int maiorCombo;
}InfoJogador;

//Fila de Cores associado a um bloco
typedef struct no{
    char *cor; //String Cor atual
    struct no *proximo;
}No;

//Estrutura dos blocos
typedef struct{
    int valor; //N�mero de cores restantes
    int coord[2]; //Coordenado do bloco
    No *cores;
}Bloco;

//Fila de Blocos
typedef struct noDeBlocos{
    Bloco bloc;
    struct noDeBlocos *proximo;
}NoDeBlocos;

//-----------//-------//------Variaveis Globais

//Variavel Global do jogador
InfoJogador jogador;
int vidas = 3;

//Define Teclas para destruir blocos
char botoes[5];

//Variavel Global do Cursor Jogar/Menu/Configura��es
int cursor = 0;
int cursorMenu = 0;
int cursorConfiguracoes = 0;

//-----------//-------//------Fun��es Gerais

void escondeCursor(int visible){
    //Fun��o que esconde o cursor do console

    //Essa � �nica fun��o que n�o teho certeza de como funciona,
    //Acabei encontrando a solu��o na internet
    //Get a console handle
    HANDLE myconsole = GetStdHandle(STD_OUTPUT_HANDLE);

    CONSOLE_CURSOR_INFO cursorC;

    cursorC.dwSize = 1;
    if(visible==0)
        cursorC.bVisible = FALSE;
    else
        cursorC.bVisible = TRUE;
    SetConsoleCursorInfo(myconsole, &cursorC);//second argument need pointer
}

void gotoxy(int x, int y){
    //Localiza e coloca o cursor em coordedana x /y
  SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), (COORD){MARGIN_LEFT+x,y});
}

void resetGoto(){
    //Reseta as configura��es de coordenada e formata��o
    gotoxy(0,ALTURA_MAX+2);
    printf(RSET);
}

char saindo(){
    resetGoto();
    printf("                                           ");
    resetGoto();
    printf(YELC "  Saindo...\n" RSET);
    Sleep(500);
    return ESC;
}

void esperarEsc(){
    resetGoto();
    printf(YELC "          Pressione ESC para voltar ao Menu");
    while(getch() != ESC);
    saindo();
}

float time_diff2(struct timespec *start, struct timespec *end){
    //Calcula a diferen�a de Tempo
    return (end->tv_sec - start->tv_sec) + 1e-9*(end->tv_nsec - start->tv_nsec);
}

char* escolherCor(int cor){
    //Defini cor atrav�s do valor num�rico correspodente
    switch(cor){
        case 0:
            return WHTB;
        case 1:
            return CYNB;
        case 2:
            return GRNB;
        case 3:
            return YELB;
        case 4:
            return REDB;
        default:
            return RSET;
    }
}

void exibirTexto(char *texto, int largura, int altura){
    char frase[128];
    strcpy(frase,texto);
    gotoxy(LARGURA_MAX-(strlen(frase)/2)+largura,(ALTURA_MAX/2)+altura);
    printf("%s",frase);
}

void exibirTela(){
    //Declarando a matrix das cores por coordenada
    //IMPORTANTE!!! cada valor de largura, equivale a 2 na hora de impririr
    int mapa[ALTURA_MAX][LARGURA_MAX];
    system("cls");
    //Definindo as cores da Tela
    for(int i=0;i<ALTURA_MAX;i++){
        for(int j=0;j<LARGURA_MAX;j++){
            //Define as bordas
            if(i==0 || i==ALTURA_MAX-1 || j==0 || j==LARGURA_MAX-1)mapa[i][j] = 0;
            //Cor do Mapa
            else mapa[i][j] = -1;
        }
    }

    //Exibindo a Tela
    for(int y =0; y<ALTURA_MAX;y++){
        for(int x=0; x<LARGURA_MAX;x++){
            gotoxy(x*2,y);
            printf("%s" espaco,escolherCor(mapa[y][x]));
        }
        printf("\n" RSET);
    }

    resetGoto();
}

//-----------//-------//------Fun��es de Jogar

void salvaStatus();//Fun��o configurado na sess�o de Ranking

void fimDeJogo(){
    gotoxy((10*2)+3,8);
    printf(REDC "Game Over");

    esperarEsc();
    //Salva a pontua��o do Jogador
    salvaStatus();
}

void atualizarPontos(){
    //Exibi a pontua��o atual
    gotoxy(ESPACO_LATERAL+(LARGURA_MAX*2)+4,4);
    printf("    ");
    gotoxy(ESPACO_LATERAL+(LARGURA_MAX*2)+4,4);
    if(jogador.pontuacao < 100)
        printf(" ");
    printf(YELC"%.0f", jogador.pontuacao);

    //Exibe o combo atual
    gotoxy(ESPACO_LATERAL+(LARGURA_MAX*2)+5,7);
    printf("    ");
    gotoxy(ESPACO_LATERAL+(LARGURA_MAX*2)+5,7);
    printf(YELC"%d", jogador.combo-1);

    resetGoto();
}

void corErrada(){
    jogador.combo = 1;
    jogador.pontuacao-=5;
    if(jogador.pontuacao <0)
        jogador.pontuacao = 0;
}

void calcularPontos(){
    //Cacula os pontos + combos
    jogador.pontuacao+=10*(1+((jogador.combo/5)*0.1));
    jogador.combo++;
    if(jogador.combo-1 > jogador.maiorCombo)
        jogador.maiorCombo = jogador.combo;
}

void removerVida(){
    vidas--;
    gotoxy(2+(LARGURA_MAX*2)+2,18);
    printf("         ");
    gotoxy(2+(LARGURA_MAX*2)+2,18);
    for(int i=0;i<vidas;i++){
        printf(REDC"  %c", 3);
    }
    resetGoto();
}

void mudarCursor(int mn){
    //Reseta a formata��o da posi��o atual do curosr
    gotoxy((10+(cursor*3))*2,19);
    printf("%s" espaco, RSET);

    //Muda a posi��o do cursor
    if(mn==0) cursor--;
    else if(mn==1) cursor++;

    //Imprime o cursor na nova posi��o
    gotoxy((10+(cursor*3))*2,19);
    printf("%s" espaco, WHTH);

    resetGoto();
}

void desenharDivisoria(int *cor){
    gotoxy(2,18);
    for(int i=0;i<(LARGURA_MAX-2)*2;i++)
        printf("%s%c",cor,175);;
}

void elementosJogar(int parte){//Parametro necess�rio para o tutorial
    if(parte>=3){
        //Colocar Cursor
        mudarCursor(2);

        //Adicionar Linha
        desenharDivisoria(WHTC);
    }

    //Impress�o da Barra Lateral
    int posiX = ESPACO_LATERAL+(LARGURA_MAX*2);

    if(parte >=1){
        gotoxy(posiX,3);
        printf(YELC" Pontua��o");
        gotoxy(posiX+5,4);
        printf(YELC"0");
    }
    if(parte >=4){
        gotoxy(posiX,6);
        printf(YELC"Combo Atual");
        gotoxy(posiX+5,7);
        printf(YELC"0");
    }
    if(parte >=5){
        gotoxy(posiX,17);
        printf(REDC"Vidas Atuais");
        gotoxy(posiX,18);
        printf("  %c  %c  %c", 3,3,3);
    }
    resetGoto();
}

//-----------------------Fun��es Fila

void inserirNaFila(No **fila, int num, char *cor){
    No *aux, *novo = malloc(sizeof(No));
    if(novo){
        novo->cor = strdup(cor);
        novo->proximo = NULL;
        if(*fila == NULL){
            *fila = novo;
        }else{
            aux = *fila;
            while(aux->proximo){
                aux = aux->proximo;
            }
            aux->proximo = novo;
        }
    }else{
        printf("\nErro ao alocar memoria\n");
    }
}

void removerDaFila(No **fila){
    No *remover = NULL;
    remover = *fila;
    *fila = remover->proximo;

    //Chama a fun��o de calcularPotnos
    calcularPontos();
}

void defineFila(No **fila, int valor){
    for(;valor!=0;valor--){
        inserirNaFila(fila,valor,escolherCor(1+(rand()%4)));
    }

}

//-----------------------Fun��es Bloco

int colocaBloco(Bloco *bloc){
    int fimDoBloco =0;
    gotoxy(bloc->coord[0],bloc->coord[1]);
    if(bloc->cores){
        if(bloc->valor!=0){
            printf(BLKC);
            printf("%s%s",bloc->cores->cor,(bloc->valor<10?"0":""));
            printf("%d",bloc->valor);
        }else{
            printf("%s  ",bloc->cores->cor);
        }
    }
    else{
        printf("%s" espaco, RSET);
        fimDoBloco =1;
    }
    resetGoto();
    return fimDoBloco;
}

Bloco criaBloco(int coluna){
    Bloco blok;
    blok.cores = NULL;
    //Coordenada x
    blok.coord[0] = (10+(coluna*3))*2;
    //Coordenada y
    blok.coord[1] = 1;
    blok.valor = 2+(rand()%3);
    defineFila(&blok.cores, blok.valor);
    colocaBloco(&blok);
    return blok;
}

int quedaBloco(Bloco *bloc, int limite){
    gotoxy(bloc->coord[0],bloc->coord[1]);

    printf("%s" espaco, RSET);

    bloc->coord[1]++;
    if(bloc->coord[1] ==limite)
        return 1;

    colocaBloco(bloc);
    resetGoto();
    return 0;
}

//-----------------------Fun��es NoDeBlocos

void inserirNaFilaDeBlocos(NoDeBlocos **fila, int coluna){
    NoDeBlocos *aux, *novo = malloc(sizeof(NoDeBlocos));
    if(novo){
        novo->bloc = criaBloco(coluna);
        novo->proximo = NULL;
        if(*fila == NULL){
            *fila = novo;
        }else{
            aux = *fila;
            while(aux->proximo){
                aux = aux->proximo;
            }
            aux->proximo = novo;
        }
    }else{
        printf("\nErro ao alocar memoria\n");
    }
}

void removerFilaDeBlocos(NoDeBlocos **fila){
    NoDeBlocos *remover = NULL;
    if(*fila){
        remover = *fila;
        *fila = remover->proximo;
    }else{
        printf("\nFila Vazia\n");
    }
}

void quedaFilaDeBlocos(NoDeBlocos **fila){
    if(*fila){
        //Se atingiu a linha, remove o bloco e causa dano
        if(quedaBloco(&(*fila)->bloc,18)==1){
            removerFilaDeBlocos(fila);
            removerVida();
            quedaFilaDeBlocos(fila);
        }else // Se n�o, passa paro o pr�ximo bloco
            quedaFilaDeBlocos(&(*fila)->proximo);
    }
}

//-----------------------Fun��es de Captura

char comandos(char key, NoDeBlocos **filaBlocos){
    //Verifica qual tecla foi pressionada
    switch(key){
        case ESC:
            return saindo();
        case ARROW_LEFT:
            if(cursor > 0)
                mudarCursor(0);
            return ' ';
        case ARROW_RIGHT:
            if(cursor < 2)
                mudarCursor(1);
            return ' ';
        /*case 'z':
            vidas=0;
            return ' ';*/
        default:
            break;
    }
    //Condi��o para que n�o possa fer poss�vel comparar cores se n�o houver cores na fila
    //Mas precisa ser poss�vel entrar nessa fun��o por causa dos outros comandos
    if(&((*filaBlocos)->bloc)!=NULL){
            if(key==botoes[0]){
                if((*filaBlocos)->bloc.cores){
                    if(strcmp((*filaBlocos)->bloc.cores->cor, escolherCor(1)) == 0){
                        removerDaFila(&((*filaBlocos)->bloc.cores));
                            (*filaBlocos)->bloc.valor--;
                    }
                    else
                        corErrada();
                }
            }else if(key==botoes[1]){
                if((*filaBlocos)->bloc.cores){
                    if(strcmp((*filaBlocos)->bloc.cores->cor, escolherCor(2)) == 0){
                        removerDaFila(&((*filaBlocos)->bloc.cores));
                        (*filaBlocos)->bloc.valor--;
                    }
                    else
                        corErrada();
                }
            }else if(key==botoes[2]){
                if((*filaBlocos)->bloc.cores){
                    if(strcmp((*filaBlocos)->bloc.cores->cor, escolherCor(3)) == 0){
                        removerDaFila(&((*filaBlocos)->bloc.cores));
                        (*filaBlocos)->bloc.valor--;
                    }
                    else
                        corErrada();
                }
            }else if(key==botoes[3]){
                if((*filaBlocos)->bloc.cores){
                    if(strcmp((*filaBlocos)->bloc.cores->cor, escolherCor(4)) == 0){
                        removerDaFila(&((*filaBlocos)->bloc.cores));
                        (*filaBlocos)->bloc.valor--;
                    }
                    else
                        corErrada();
                }
            }else{
                return;
            }
    }else return ' ';

    //Atualiza a barra de pontos
    //S� ser� acesado se passar pela compara��o de cores
    atualizarPontos();
    return ' ';
}

void recebeNome(){
    exibirTela();
    gotoxy(8,3);
    printf(CYNC"Parab�ns"RSET" sua "GRNC"PONTUA��O"RSET" est� no "YELC"TOP 10"RSET"!!");
    gotoxy(8,5);
    printf("Como voc� deseja ser chamado?");
    gotoxy(12,7);
    printf(REDC"%c "RSET, 16);
    for(int i=0; i<=17; i++){
        jogador.nome[i] = '\0';
    }
    fflush(stdin);

    escondeCursor(1);
    fgets(jogador.nome,17,stdin);
    escondeCursor(0);

    jogador.nome[strlen(jogador.nome)-1]='\0';//Remove o enter do ultimo caracter
}

//-----------------------Fun��es principal Jogar

void jogar(){
    //Define ou Redefine os valores do jogador;
    cursor = 1;
    vidas = 3;
    jogador.pontuacao = 0;
    jogador.combo = 1;
    jogador.maiorCombo = 0;

    srand(time(NULL));
    struct timespec start1, start2, start3, end;

    int aumentaSpawn = 0;
    //Variaveis de dificuldade
    float velocidadeQueda = 1.5;
    float velocidadeSpawn = 3.5;

    exibirTela();
    elementosJogar(10);

    //Declara uma array de filas de Blocos
    //Cada fila representa uma coluna, da esquerda para direita
    NoDeBlocos *filaBlocos[3];
    for(int i=0;i<3;i++){
        filaBlocos[i]=NULL;
    }
    int randomNum = rand()%3;
    inserirNaFilaDeBlocos(&filaBlocos[randomNum], randomNum);

    //Inicia os temporizadores
    //Primeiro clock armazena o tempo para colocar bloco
    clock_gettime(CLOCK_REALTIME, &start1);
    //Segundo clock armazena o tempo para os blocos cairem
    clock_gettime(CLOCK_REALTIME, &start2);
    //Terceiro clock armazena o tempo para diminuir o tempo de spawn
    clock_gettime(CLOCK_REALTIME, &start3);

    char key = ' ';
    while(key != ESC){
        fflush(stdin);
        if (kbhit()) {
            key = comandos(getch(),&filaBlocos[cursor]);;
            //Verfica se existe bloco na coluna do cursor
            if(&(filaBlocos[cursor]->bloc)!=NULL){
                //Verifica se as cores no bloco acabaram
                if(colocaBloco(&(filaBlocos[cursor]->bloc))==1)
                    //Se sim, remove da fila
                    removerFilaDeBlocos(&filaBlocos[cursor]);
            }
        }
        clock_gettime(CLOCK_REALTIME, &end);
        //Verifica se o tempo necess�rio, para os blocos cairem, passou
        if(time_diff2(&start2, &end) >=velocidadeQueda){
            clock_gettime(CLOCK_REALTIME, &start2);
            //Faz os blocos de todas as colunas cairem
            for(int i=0;i<3;i++)
                quedaFilaDeBlocos(&filaBlocos[i]);
            if(vidas <= 0){
                fimDeJogo();
                key = ESC;
            }
        }
        //Verifica se o tempo necess�rio, para novos blocos surgirem, passou
        if(time_diff2(&start1, &end) >=velocidadeSpawn){
            clock_gettime(CLOCK_REALTIME, &start1);
            //Escolhe uma coluna aleat�ria
            randomNum = rand()%3;
            //Adiciona um novo bloco a uma das 3 colunas
            inserirNaFilaDeBlocos(&filaBlocos[randomNum],randomNum);
        }
        //Verifica se o tempo necess�rio, para aumentar a velocidade de queda, passou
        if(time_diff2(&start3, &end) >=5){
            clock_gettime(CLOCK_REALTIME, &start3);
            //Aumenta a velocidade de queda em 0.05, no m�nimo 0.1
            if(velocidadeQueda >= 0.5)
                velocidadeQueda-=0.02;
            //Armazena multiplos de 5 secs
            aumentaSpawn++;
        }
        //Verifica se o tempo necess�rio, aumentar a velocidade de Spawn, passou, em Multiplos de 5
        if(aumentaSpawn == 4){
            if(velocidadeSpawn>1)
                velocidadeSpawn-=0.25;
            //Reseta o contador de tempo
            aumentaSpawn=0;
        }
    }
}

//-----------//-------//------Fun��es Do Tutorial

void exibirTutorialParte(int parte){
    int formatacao = 6; //Define o tamanho que uma formata��o ocupa na string
    cursor = 1;
    exibirTela();

    elementosJogar(parte);

    switch(parte){
        case 0:
            exibirTexto(CYNC"Bem "GRNC"vindo "YELC"ao "REDC"Tutorial!"RSET,(formatacao*3)-1,-6);
            exibirTexto("Use as "WHTU"SETAS"RSET" para navegar no tutorial",formatacao+1,-3);
            exibirTexto("Use "WHTU"ESC"RSET" para sair do tutorial",formatacao+1,-1);

            break;

        case 1:
            exibirTexto("Seu objetivo principal � ",0,-4);
            exibirTexto(GRNC"sobreviver"RSET" �s quedas dos "WHTU"BLOCOS"RSET" "CYNC"CO"GRNC"LO"YELC"RI"REDC"DOS"RSET,(formatacao*4)+6,-3);
            exibirTexto("fazendo a "YELC"maior pontua��o"RSET" poss�vel!",formatacao,-2);

            gotoxy((LARGURA_MAX*2)-7,3);
            printf(REDC"--%c",16);
            break;
        case 2:
            gotoxy(LARGURA_MAX-10,3);
            printf(REDC"--%c "RSET,16);
            printf(BLKC);
            printf(CYNB"02"BLKB"  "GRNB"02"BLKB"  "YELB"02"BLKB"  "REDB"02"RSET);

            exibirTexto("Estes s�o os "WHTU"BLOCOS"RSET" "CYNC"CO"GRNC"LO"YELC"RI"REDC"DOS"RSET,(formatacao*3)+5,-7);
            exibirTexto("Cada "WHTU"BLOCO"RSET" possue uma sequ�ncia de ",(formatacao)+1,-5);
            exibirTexto("2 � 4 "GRNC"CORES"RSET", que devem ser destru�dos",(formatacao),-4);
            exibirTexto("em ordem, para qu� enfim, se quebre",0,-3);

            exibirTexto("Para isso � necess�rio pressionar a tecla",0,-1);
            exibirTexto("correspondente a "GRNC"COR"RSET", na "WHTU"COLUNA"RSET" correta",(formatacao*2),0);

            gotoxy(LARGURA_MAX-12,(ALTURA_MAX/2)+2);
            printf(REDC"--%c "RSET,16);
            printf(BLKC);
            printf(CYNB" %c "BLKB"  "GRNB" %c "BLKB"  "YELB" %c "BLKB"  "REDB" %c "RSET,botoes[0],botoes[1],botoes[2],botoes[3]);

            exibirTexto("As teclas podem ser configuradas no menu",0,4);
            break;
        case 3:
            exibirTexto("Este ("WHTH"  "RSET") � seu "CYNC"CURSOR"RSET", para control�-lo",formatacao*2+1,-6);
            exibirTexto("use as "WHTU"SETAS"RSET": ESQUERDA e DIREITA",formatacao+1,-5);
            exibirTexto("O "CYNC"CURSOR"RSET" representa",formatacao+1,-2);
            exibirTexto("a "WHTU"COLUNA"RSET" atual",formatacao+1,-1);

            gotoxy((7+(cursor*3))*2,19);
            printf(REDC"--%c",16);
            break;
        case 4:
            exibirTexto("Para cada "GRNC"acerto"RSET,formatacao,-8);
            exibirTexto(GRNC"10 pontos"RSET" s�o ganhos e",formatacao,-7);
            exibirTexto("combo atual "GRNC"aumenta"RSET" em 1",formatacao,-6);

            exibirTexto("Por�m, a cada "REDC"erro"RSET,formatacao,-3);
            exibirTexto(REDC"5 pontos"RSET" s�o perdidos e",formatacao,-2);
            exibirTexto("combo atual � "REDC"reduzido"RSET" a 0",formatacao,-1);

            exibirTexto("A cada 5 pontos de "YELC"Combo"RSET,formatacao,2);
            exibirTexto(YELC"+1 ponto"RSET" � recebido por "GRNC"acerto"RSET,(formatacao*2)+1,3);

            gotoxy((LARGURA_MAX*2)-7,6);
            printf(REDC"--%c",16);
            break;
        case 5:
            exibirTexto("O jogo "REDC"termina"RSET" quando",formatacao+1,-8);
            exibirTexto("suas "REDC"VIDAS"RSET" se esgotarem",formatacao+1,-7);

            exibirTexto("Voc� perde uma de suas "REDC"VIDAS"RSET,formatacao+1,-3);
            exibirTexto("a cada "WHTU"BLOCO"RSET" que",formatacao+1,-2);
            exibirTexto("encostar na",0,-1);
            exibirTexto(CYNC"divis�ria"RSET,formatacao+1,0);

            desenharDivisoria(CYNC);

            gotoxy(LARGURA_MAX+8,ALTURA_MAX-9);
            printf(REDC"|");
            gotoxy(LARGURA_MAX+8,ALTURA_MAX-8);
            printf(REDC"%c",31);

            gotoxy((LARGURA_MAX*2)-7,ALTURA_MAX-8);
            printf(REDC"--%c",16);
            break;
        case 6:
            exibirTexto("Quando o jogo "REDC"termina"RSET",",formatacao,-8);
            exibirTexto("se sua "YELC"PONTUA��O"RSET" for maior que",formatacao,-7);
            exibirTexto("a 10� posi��o do rank",0,-6);
            exibirTexto("Voc� pode salvar seu "CYNC"NOME"RSET",",formatacao,-4);
            exibirTexto("junto da sua "YELC"PONTUA��O"RSET" e Maior "YELC"COMBO"RSET,formatacao*2+1,-3);
            exibirTexto("O "GRNC"RANKING"RSET" pode ser",formatacao,-1);
            exibirTexto("acessado no "CYNC"Menu Principal"RSET,formatacao,0);
            break;
        case 7:
            exibirTexto("Este � o "REDC"FIM"RSET" do "CYNC"Tutorial"RSET,formatacao*2+1,-8);
            exibirTexto("Agora � o momento de provar do que voc� � capaz",0,-5);
            exibirTexto(CYNC"Desafie-se"RSET" e "GRNC"Conquiste"RSET" o topo do "YELC"Ranking"RSET,(formatacao*3)+1,-4);
            exibirTexto("Pressione "WHTU"ESC"RSET" para voltar ao "CYNC"Menu Principal"RSET,formatacao*2+1,1);
            break;
    }
    resetGoto();
}

char comandosTutorial(char key, int parte){
    switch(key){
        case ESC:
            saindo();
            return -1;
        case ARROW_LEFT:
            if(parte>0){
                parte--;
                exibirTutorialParte(parte);
            }
            break;
        case ARROW_RIGHT:
            if(parte<7){
                parte++;
                exibirTutorialParte(parte);
            }
            break;
    }
    return parte;
}

void tutorial(){
    int tutorialParte=0;
    exibirTutorialParte(tutorialParte);

    while(tutorialParte != -1){
        fflush(stdin);
        tutorialParte = comandosTutorial(getch(),tutorialParte);
    }
}

//-----------//-------//------Fun��es Do Ranking

int exibiRank(){
    FILE *rank;
    rank = fopen("ranking.rank","rb");
    InfoJogador jogadorRank;

    if (rank == NULL){
        gotoxy(0,ALTURA_MAX+1);
        printf("Ocorreu um problema ao abrir o arquivo ranking.rank");
        esperarEsc();
        return 1;
    }else{
        for(int i = 1;i<=10;i++){
            fread(&jogadorRank, sizeof(InfoJogador), 1, rank);
            gotoxy((LARGURA_MAX-8)/2,i*2);
            switch(i){
                case 1:
                    printf(YELC);
                    break;
                case 2:
                    printf(GRNC);
                    break;
                case 3:
                    printf(CYNC);
                    break;
                default:
                    printf(RSET);
                    break;
            }
            printf("Rank %i. %s - %.0f P - %i C", i,jogadorRank.nome, jogadorRank.pontuacao, jogadorRank.maiorCombo);
        }
        fclose(rank);
        int posiX = ESPACO_LATERAL+(LARGURA_MAX*2);
        gotoxy(posiX+2,3);
        printf(REDC"Legenda"RSET);
        gotoxy(posiX,5);
        printf("P -> Pontua��o");
        gotoxy(posiX,7);
        printf("C -> Maior Combo");
    }
    return 0;
}

void organizaRank(){
    FILE *rank, *temp;
    InfoJogador jTemp[11], jTemp2;

    rank = fopen("ranking.rank", "rb");

    resetGoto();
    if (rank == NULL){
        gotoxy(0,ALTURA_MAX+1);
        printf("Ocorreu um problema ao abrir o arquivo ranking.rank");
        esperarEsc();
    }
    else{
        temp = fopen("ranking.temp", "wb");
        if (temp == NULL){
            gotoxy(0,ALTURA_MAX+1);
            printf("Ocorreu um problema ao abrir o arquivo ranking.temp");
            esperarEsc();
        }else{
            for(int i=0;i<11;i++){
                strcpy(jTemp[i].nome, "");
                jTemp[i].pontuacao = 0;
                jTemp[i].combo = 0;
                jTemp[i].maiorCombo = 0;
                if(!feof(rank))
                    fread(&jTemp[i],sizeof(InfoJogador),1,rank);
            }
            //Colocando i at� 10, faz com que eu tenha at� 11 InfoJogador, mas salve apenas 10, sempre deixando 1 espa�o
            for(int i=0;i<10;i++){
                for(int j=i+1;j<11;j++){
                    if(jTemp[i].pontuacao < jTemp[j].pontuacao){
                        jTemp2 = jTemp[i];
                        jTemp[i] = jTemp[j];
                        jTemp[j] = jTemp2;
                    }
                }
                fwrite(&jTemp[i],sizeof(InfoJogador),1,temp);
            }
            fclose(temp);
            fclose(rank);

            remove("ranking.rank");
            rename("ranking.temp", "ranking.rank");
        }
    }
}

void salvaStatus(){
    FILE *rank;
    rank = fopen("ranking.rank","a+b");

    if (rank == NULL){
        gotoxy(0,ALTURA_MAX+1);
        printf("Ocorreu um problema ao abrir o arquivo ranking.rank");
        esperarEsc();
    }else{
        InfoJogador rank10;
        strcpy(rank10.nome, "");
        rank10.pontuacao = 0;
        rank10.combo = 0;
        rank10.maiorCombo = 0;
        fseek(rank,sizeof(InfoJogador)*9,0);
        fread(&rank10,sizeof(InfoJogador),1,rank);

        if(jogador.pontuacao>rank10.pontuacao){
            recebeNome();
            fseek(rank,0,2);
            fwrite(&jogador, sizeof(InfoJogador), 1, rank);
            fclose(rank);
            organizaRank();
        }else{
            fclose(rank);
        }
    }
}

void ranking(){
    exibirTela();
    exibiRank();
    esperarEsc();
}

//-----------//-------//------Fun��es De Configura��o

void defineBotoes(){
    //Fun��o le arquivo texto armazenado com 4 chars
    FILE *config = NULL;
    if((config = fopen("./config.txt","r")) == NULL){
        fprintf(stderr,"error opening File ./config.txt\n");
        return;
    }else{
        fgets(botoes,sizeof(botoes),config);
        botoes[strcspn(botoes, "\n")] = 0;
    }
    fclose(config);

}

void alterarBotao(char botao){
    //Altera o botao na coluna equivalente a cursorConfuguracoes, e escreve no config.txt
    FILE *config = NULL;
    if((config = fopen("./config.txt","w")) == NULL){
        fprintf(stderr,"error opening File ./config.txt\n");
        return;
    }else{
        botoes[cursorConfiguracoes] = botao;
        fwrite(&botoes,sizeof(botoes)-1,1,config);
    }
    fclose(config);
}

void mudarCursorConfiguracoes(int mn){
    //Reseta a formata��o da posi��o atual do curosr
    gotoxy(LARGURA_MAX-8+(cursorConfiguracoes*5),(ALTURA_MAX/2)-1);
    printf(RSET" ");

    //Muda a posi��o do cursor
    if(mn==0) cursorConfiguracoes--;
    else if(mn==1) cursorConfiguracoes++;

    gotoxy(LARGURA_MAX-8+(cursorConfiguracoes*5),(ALTURA_MAX/2)-1);
    printf(WHTC "%c", 30);

    resetGoto();
}

void exibirCofiguracoes(){
    exibirTela();
    mudarCursorConfiguracoes(-1);

    exibirTexto("Selecione o Bot�o que gostaria de alterar",0,-7);

    gotoxy(LARGURA_MAX-9,(ALTURA_MAX/2)-3);
    printf(BLKC);
    printf(CYNB" %c "BLKB"  "GRNB" %c "BLKB"  "YELB" %c "BLKB"  "REDB" %c "RSET,botoes[0],botoes[1],botoes[2],botoes[3]);

    resetGoto();
    printf(YELC "          Pressione ESC para voltar ao Menu");
}

char comandosConfiguracoes(char opcao){
    switch(opcao){
        case ESC:
            saindo();
            return ESC;
        case ARROW_RIGHT:
            if(cursorConfiguracoes<3)
                mudarCursorConfiguracoes(1);
            break;
        case ARROW_LEFT:
            if(cursorConfiguracoes>0)
                mudarCursorConfiguracoes(0);
            break;
        case ENTER:
            exibirTexto(RSET"Digite a nova tecla:",3,2);
            gotoxy(LARGURA_MAX-2,(ALTURA_MAX/2)+3);
            printf(WHTC"%c "RSET, 16);

            escondeCursor(1);

            char novaTecla[2];
            scanf("%c",&novaTecla);
            novaTecla[strcspn(novaTecla, "\n")] = 0;
            alterarBotao(novaTecla[0]);

            escondeCursor(0);
            exibirCofiguracoes();
            break;
    }
    return ' ';
}

void configuracoes(){
    exibirCofiguracoes();
    char key = ' ';
    while(key != ESC){
        fflush(stdin);
        if (kbhit())
            key = comandosConfiguracoes(getch());
    }
}

//-----------//-------//------Fun��es Do Menu Principal

void exibirOpcoes(){
    gotoxy((LARGURA_MAX-5)+2,8);
    printf("Jogar");
    gotoxy((LARGURA_MAX-5)+2,9);
    printf("Ranking");
    gotoxy((LARGURA_MAX-5)+2,10);
    printf("Tutorial");
    gotoxy((LARGURA_MAX-5)+2,11);
    printf("Configura��es");
    gotoxy((LARGURA_MAX-5)+2,12);
    printf("Sair");

    resetGoto();
}

void mudarCursorMenu(int mn){
    //Reseta a formata��o da posi��o atual do curosr
    gotoxy(LARGURA_MAX-5,8+cursorMenu);
    printf(RSET" ");

    //Muda a posi��o do cursor
    if(mn==0) cursorMenu--;
    else if(mn==1) cursorMenu++;

    gotoxy(LARGURA_MAX-5,8+cursorMenu);
    printf(CYNC "%c", 16);

    resetGoto();
}

void exibirASCII(){
    char *filename = "./ASCII/ColorFall.txt";
    FILE *fptr = NULL;

    if((fptr = fopen(filename,"r")) == NULL){
        fprintf(stderr,"error opening File ./ASCII/ColorFall.txt\n");
        return;
    }else{
        char read_string[128];
        int linha=0;
        while(fgets(read_string,sizeof(read_string),fptr) != NULL){
            gotoxy(5,2+linha);
            for(int i=0;i<strlen(read_string);i++){
                switch(i){
                    case 0:
                        printf(CYNC);
                        break;
                    case 12:
                        printf(GRNC);
                        break;
                    case 26:
                        printf(YELC);
                        break;
                    case 38:
                        printf(REDC);
                        break;
                }
                printf("%c",read_string[i]);
            }
            linha++;
        }
        printf(RSET);
    }
    fclose(fptr);
}

void exibirMenu(){
    exibirTela();
    exibirOpcoes();
    exibirASCII();
    mudarCursorMenu(-1);
}

int calculaCordColuna(int coluna){
    int cordColuna[5];
    cordColuna[0] = 2+2;
    cordColuna[1] = 2+15;
    cordColuna[2] = LARGURA_MAX+5;
    cordColuna[3] = LARGURA_MAX+15;
    cordColuna[4] = (LARGURA_MAX*2)-2-2;

    return cordColuna[coluna]+(rand()% (cordColuna[coluna+1]-cordColuna[coluna]));
}

Bloco criaBlocoMenu(int coluna){
    Bloco blok;
    blok.cores = malloc(sizeof(No));
    blok.cores->cor = escolherCor(coluna+1);
    blok.valor=0;

    switch(coluna){
        //Adicionar numeros aleatorios
        case 0:
            blok.coord[0] = calculaCordColuna(coluna);
            blok.coord[1] = 9+(rand()%5);
            break;
        case 1:
            blok.coord[0] = calculaCordColuna(coluna);
            blok.coord[1] = 14+(rand()%3);
            break;
        case 2:
            blok.coord[0] = calculaCordColuna(coluna);
            blok.coord[1] = 14+(rand()%3);
            break;
        case 3:
            blok.coord[0] = calculaCordColuna(coluna);
            blok.coord[1] = 9+(rand()%5);
            break;
    }

    colocaBloco(&blok);
    return blok;
}

char comandosMenu(char key){
    switch(key){
        SAIR: case ESC:
            return saindo();
        case ARROW_UP:
            if(cursorMenu >0){
                mudarCursorMenu(0);
            }
            break;
        case ARROW_DOWN:
            if(cursorMenu <4){
                mudarCursorMenu(1);
            }
            break;
        case ENTER:
            switch(cursorMenu){
                case 0:
                    jogar();
                    break;
                case 1:
                    ranking();
                    break;
                case 2:
                    tutorial();
                    break;
                case 3:
                    configuracoes();
                    break;
                case 4:
                    goto SAIR;
            }
            exibirMenu();
            break;
        default:
            break;
    }
    return ' ';
}

void menuPrincipal(){
    //Exibe o menu
    exibirMenu();

    struct timespec start, end1;

    Bloco blocos[4];
    for(int i=0;i<4;i++)
        blocos[i]= criaBlocoMenu(i);

    //Clock armazena o tempo para os blocos cairem
    clock_gettime(CLOCK_REALTIME, &start);

    char key = ' ';
    while(key != ESC){
        fflush(stdin);
        if (kbhit())
            key = comandosMenu(getch());

        clock_gettime(CLOCK_REALTIME, &end1);
        //Verifica se o tempo necess�rio, para os blocos cairem, passou
        if(time_diff2(&start, &end1) >=0.5){
            clock_gettime(CLOCK_REALTIME, &start);
            //Faz os blocos de todas as colunas cairem
            for(int i=0;i<4;i++)
                if(quedaBloco(&blocos[i], ALTURA_MAX-2)==1)
                    blocos[i] = criaBlocoMenu(i);
        }
    }
}

//-----------//-------//------Main
int main(){
    setlocale(LC_CTYPE , "");
    system("cls");
    //Chama a fun��o para esconder o cursor
    escondeCursor(0);
    //Chama a fun��o que le arquivo contendo as configura��es de botoes
    defineBotoes();

    //Chama o menu principal
    menuPrincipal();

    return 0;
}
